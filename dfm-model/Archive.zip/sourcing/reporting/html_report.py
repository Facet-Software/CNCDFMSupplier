# sourcing/reporting/html_report.py
# Generates a self-contained single-page HTML report for suppliers.
# Includes a Three.js 3D viewer that highlights faces when DFM flags / holes
# are clicked. No build step — React + Babel + Three.js loaded from CDN.

import json
import pathlib


_COMPONENT_JSX = r"""
const R = window.__REPORT__;
const HAS_GEO = R.geometry && R.geometry.length > 0;

const HOLE_LABELS = {
  through:             "Through",
  through_counterbore: "Counterbore",
  through_countersink: "Countersink",
  blind_flat:          "Blind (flat)",
  blind_with_tip:      "Blind (drill tip)",
  thread:              "Thread",
};
const SEV_COLOR  = { critical: "#c0392b", warning: "#d97706", advisory: "#6b7280", info: "#2563eb" };
const SEV_BG     = { critical: "#fef2f2", warning: "#fffbeb", advisory: "#f9fafb", info: "#eff6ff" };
const SEV_BORDER = { critical: "#fca5a5", warning: "#fcd34d", advisory: "#e5e7eb", info: "#bfdbfe" };
const SEV_LABEL  = { critical: "CRITICAL", warning: "WARNING", advisory: "ADVISORY", info: "FEATURE" };

// ── 3D VIEWER ─────────────────────────────────────────────────────────────────
function Viewer3D({ selectedFaceIdxs, labelText, labelSev, activeFixture, snapRef, captureRef, onOrbitRef, onDeselect }) {
  const containerRef = React.useRef(null);
  const threeRef     = React.useRef({});
  const svgLineRef   = React.useRef(null);
  const svgDotRef    = React.useRef(null);
  const selectedRef  = React.useRef([]);
  const arrowRef     = React.useRef(null);
  const edgesRef     = React.useRef([]);    // LineSegments for fixturing edges
  const snapTargetRef = React.useRef(null); // {theta, phi} to animate to

  // ── INIT ──
  React.useEffect(() => {
    if (!containerRef.current || !HAS_GEO) return;
    const el = containerRef.current;

    const scene    = new THREE.Scene();
    scene.background = new THREE.Color(0xf8f8f8);
    const camera   = new THREE.PerspectiveCamera(45, el.clientWidth / el.clientHeight, 0.01, 100000);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(el.clientWidth, el.clientHeight);
    el.appendChild(renderer.domElement);

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.55));
    const sun = new THREE.DirectionalLight(0xfff8f0, 0.85);
    sun.position.set(1, 2, 1.5); scene.add(sun);
    const fill = new THREE.DirectionalLight(0xe0eeff, 0.25);
    fill.position.set(-1, -0.5, -1); scene.add(fill);

    // Per-face meshes
    const faceMeshes = {};
    const MAT_DEFAULT   = () => new THREE.MeshPhongMaterial({ color: 0xd4d4d4, specular: 0x222222, shininess: 18, side: THREE.DoubleSide });
    const MAT_HIGHLIGHT = () => new THREE.MeshPhongMaterial({ color: 0xf97316, specular: 0x441100, shininess: 30, emissive: new THREE.Color(0x1a0500), side: THREE.DoubleSide });
    const MAT_DIM       = () => new THREE.MeshPhongMaterial({ color: 0xe0e0e0, specular: 0x111111, shininess: 5, side: THREE.DoubleSide });
    const MAT_FIXTURE   = () => new THREE.MeshPhongMaterial({ color: 0xc7d8f5, specular: 0x1133aa, shininess: 22, side: THREE.DoubleSide });
    const MAT_REST      = () => new THREE.MeshPhongMaterial({ color: 0x34d399, specular: 0x116633, shininess: 28, emissive: new THREE.Color(0x052e16), side: THREE.DoubleSide });
    const MAT_CLAMP     = () => new THREE.MeshPhongMaterial({ color: 0xfbbf24, specular: 0x664400, shininess: 28, emissive: new THREE.Color(0x1c1000), side: THREE.DoubleSide });

    let bbox = new THREE.Box3();
    R.geometry.forEach(fd => {
      try {
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(fd.v), 3));
        geo.setIndex(fd.t);
        geo.computeVertexNormals();
        const mesh = new THREE.Mesh(geo, MAT_DEFAULT());
        mesh.userData.faceIdx = fd.i;
        faceMeshes[fd.i] = mesh;
        scene.add(mesh);
        bbox.expandByObject(mesh);
      } catch(e) {}
    });

    const center = new THREE.Vector3(); bbox.getCenter(center);
    const size   = new THREE.Vector3(); bbox.getSize(size);
    const maxDim = Math.max(size.x, size.y, size.z);

    const orbit = {
      theta: Math.PI * 0.35, phi: Math.PI * 0.30,
      radius: maxDim * 1.8, target: center.clone(),
      isDragging: false, isPanning: false, lastX: 0, lastY: 0,
    };

    function updateCamera() {
      const { theta, phi, radius, target } = orbit;
      camera.position.set(
        target.x + radius * Math.sin(phi) * Math.cos(theta),
        target.y + radius * Math.cos(phi),
        target.z + radius * Math.sin(phi) * Math.sin(theta),
      );
      camera.lookAt(target);
    }

    // --- Coordinate axes gizmo (bottom-left corner) ---
    const gizmoScene  = new THREE.Scene();
    const gizmoSize   = 90; // px
    const gizmoCam    = new THREE.OrthographicCamera(-1.8, 1.8, 1.8, -1.8, 0.1, 100);

    // Axis shafts + cones for X (red), Y (green), Z (blue)
    const axisLen = 1.0;
    const axisDirs = [
      { dir: new THREE.Vector3(1,0,0), color: 0xef4444, label: "X" },
      { dir: new THREE.Vector3(0,1,0), color: 0x22c55e, label: "Y" },
      { dir: new THREE.Vector3(0,0,1), color: 0x3b82f6, label: "Z" },
    ];
    axisDirs.forEach(({ dir, color }) => {
      // Shaft
      const shaftGeo = new THREE.CylinderGeometry(0.04, 0.04, axisLen, 6);
      shaftGeo.translate(0, axisLen / 2, 0);
      shaftGeo.rotateX(Math.PI / 2);
      const shaft = new THREE.Mesh(shaftGeo, new THREE.MeshBasicMaterial({ color }));
      shaft.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir);
      gizmoScene.add(shaft);
      // Cone tip
      const coneGeo = new THREE.ConeGeometry(0.1, 0.25, 8);
      coneGeo.translate(0, 0.125, 0);
      coneGeo.rotateX(Math.PI / 2);
      const cone = new THREE.Mesh(coneGeo, new THREE.MeshBasicMaterial({ color }));
      cone.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir);
      cone.position.copy(dir.clone().multiplyScalar(axisLen));
      gizmoScene.add(cone);
    });
    // Origin sphere
    gizmoScene.add(new THREE.Mesh(
      new THREE.SphereGeometry(0.07, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0x9ca3af })
    ));

    // Axis labels as canvas sprites
    function makeLabel(text, color) {
      const canvas = document.createElement('canvas');
      canvas.width = 64; canvas.height = 64;
      const ctx = canvas.getContext('2d');
      ctx.font = 'bold 48px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = color;
      ctx.fillText(text, 32, 32);
      const tex = new THREE.CanvasTexture(canvas);
      const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false });
      const sprite = new THREE.Sprite(mat);
      sprite.scale.set(0.4, 0.4, 0.4);
      return sprite;
    }
    const labelX = makeLabel('X', '#ef4444'); labelX.position.set(1.45, 0, 0); gizmoScene.add(labelX);
    const labelY = makeLabel('Y', '#22c55e'); labelY.position.set(0, 1.45, 0); gizmoScene.add(labelY);
    const labelZ = makeLabel('Z', '#3b82f6'); labelZ.position.set(0, 0, 1.45); gizmoScene.add(labelZ);
    updateCamera();

    // Controls
    const canvas = renderer.domElement;
    const onDown  = (e) => { if (e.button === 2 || e.ctrlKey) orbit.isPanning = true; else orbit.isDragging = true; orbit.lastX = e.clientX; orbit.lastY = e.clientY; e.preventDefault(); };
    const onMove  = (e) => {
      const dx = e.clientX - orbit.lastX, dy = e.clientY - orbit.lastY;
      orbit.lastX = e.clientX; orbit.lastY = e.clientY;
      if (orbit.isDragging) {
        orbit.theta -= dx * 0.008;
        orbit.phi = Math.max(0.05, Math.min(Math.PI - 0.05, orbit.phi + dy * 0.008));
        updateCamera();
        if (onOrbitRef && onOrbitRef.current) onOrbitRef.current();
      } else if (orbit.isPanning) {
        const right = new THREE.Vector3().crossVectors(camera.getWorldDirection(new THREE.Vector3()), camera.up).normalize();
        const up    = camera.up.clone().normalize();
        const s = orbit.radius * 0.001;
        orbit.target.addScaledVector(right, -dx * s).addScaledVector(up, dy * s);
        updateCamera();
        if (onOrbitRef && onOrbitRef.current) onOrbitRef.current();
      }
    };
    const onUp    = () => { orbit.isDragging = false; orbit.isPanning = false; };
    const onWheel = (e) => {
      orbit.radius = Math.max(maxDim * 0.1, Math.min(maxDim * 10, orbit.radius * (1 + e.deltaY * 0.001)));
      updateCamera(); e.preventDefault();
      if (onOrbitRef && onOrbitRef.current) onOrbitRef.current();
    };
    canvas.addEventListener('mousedown', onDown);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    canvas.addEventListener('wheel', onWheel, { passive: false });
    canvas.addEventListener('contextmenu', e => e.preventDefault());

    // Touch
    let ltd = 0;
    canvas.addEventListener('touchstart', e => {
      if (e.touches.length === 1) { orbit.isDragging = true; orbit.lastX = e.touches[0].clientX; orbit.lastY = e.touches[0].clientY; }
      if (e.touches.length === 2) ltd = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      e.preventDefault();
    }, { passive: false });
    canvas.addEventListener('touchmove', e => {
      if (e.touches.length === 1) {
        const dx = e.touches[0].clientX - orbit.lastX, dy = e.touches[0].clientY - orbit.lastY;
        orbit.lastX = e.touches[0].clientX; orbit.lastY = e.touches[0].clientY;
        orbit.theta -= dx * 0.008;
        orbit.phi = Math.max(0.05, Math.min(Math.PI - 0.05, orbit.phi + dy * 0.008));
        updateCamera();
        if (onOrbitRef && onOrbitRef.current) onOrbitRef.current();
      }
      if (e.touches.length === 2) {
        const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        orbit.radius = Math.max(maxDim * 0.1, Math.min(maxDim * 10, orbit.radius * ltd / d));
        ltd = d; updateCamera();
        if (onOrbitRef && onOrbitRef.current) onOrbitRef.current();
      }
      e.preventDefault();
    }, { passive: false });
    canvas.addEventListener('touchend', () => { orbit.isDragging = false; });

    // Resize
    const ro = new ResizeObserver(() => {
      camera.aspect = el.clientWidth / el.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(el.clientWidth, el.clientHeight);
    });
    ro.observe(el);

    // Render loop
    let animId;
    function animate() {
      animId = requestAnimationFrame(animate);

      // Smooth snap animation
      if (snapTargetRef.current) {
        const t = snapTargetRef.current;
        orbit.theta += (t.theta - orbit.theta) * 0.12;
        orbit.phi   += (t.phi   - orbit.phi)   * 0.12;
        if (Math.abs(t.theta - orbit.theta) < 0.001 && Math.abs(t.phi - orbit.phi) < 0.001) {
          orbit.theta = t.theta; orbit.phi = t.phi;
          snapTargetRef.current = null;
        }
        updateCamera();
      }

      renderer.render(scene, camera);

      // Render coordinate axes gizmo in bottom-left corner
      renderer.autoClear = false;
      const gY = el.clientHeight - gizmoSize;
      renderer.setViewport(0, gY, gizmoSize, gizmoSize);
      renderer.setScissor(0, gY, gizmoSize, gizmoSize);
      renderer.setScissorTest(true);
      renderer.clearDepth();
      gizmoCam.position.set(
        4 * Math.sin(orbit.phi) * Math.cos(orbit.theta),
        4 * Math.cos(orbit.phi),
        4 * Math.sin(orbit.phi) * Math.sin(orbit.theta),
      );
      gizmoCam.lookAt(0, 0, 0);
      renderer.render(gizmoScene, gizmoCam);
      renderer.setViewport(0, 0, el.clientWidth, el.clientHeight);
      renderer.setScissor(0, 0, el.clientWidth, el.clientHeight);
      renderer.setScissorTest(false);
      renderer.autoClear = true;

      // SVG leader line
      const idxs = selectedRef.current;
      if (idxs.length > 0 && svgLineRef.current && svgDotRef.current) {
        let cx = 0, cy = 0, cz = 0, n = 0;
        idxs.forEach(idx => {
          const fd = R.geometry.find(f => f.i === idx);
          if (!fd) return;
          for (let i = 0; i < fd.v.length; i += 3) { cx += fd.v[i]; cy += fd.v[i+1]; cz += fd.v[i+2]; n++; }
        });
        if (n > 0) {
          const sp = new THREE.Vector3(cx/n, cy/n, cz/n).project(camera);
          const rect = canvas.getBoundingClientRect();
          const px = (sp.x * 0.5 + 0.5) * rect.width;
          const py = (-sp.y * 0.5 + 0.5) * rect.height;
          svgLineRef.current.setAttribute('x1', 18); svgLineRef.current.setAttribute('y1', rect.height - 18);
          svgLineRef.current.setAttribute('x2', px);  svgLineRef.current.setAttribute('y2', py);
          svgDotRef.current.setAttribute('cx', px);   svgDotRef.current.setAttribute('cy', py);
          svgLineRef.current.style.display = ''; svgDotRef.current.style.display = '';
        }
      } else {
        if (svgLineRef.current) svgLineRef.current.style.display = 'none';
        if (svgDotRef.current)  svgDotRef.current.style.display  = 'none';
      }
    }
    animate();

    threeRef.current = { renderer, scene, camera, faceMeshes, MAT_DEFAULT, MAT_HIGHLIGHT, MAT_DIM, MAT_FIXTURE, MAT_REST, MAT_CLAMP, center, maxDim, orbit, updateCamera };

    // Expose snap function
    if (snapRef) snapRef.current = (approachVec) => {
      const [ax, ay, az] = approachVec;
      const phi   = Math.acos(Math.max(-1, Math.min(1, ay / Math.sqrt(ax*ax+ay*ay+az*az))));
      const theta = Math.atan2(az, ax);
      snapTargetRef.current = { theta, phi };
    };

    // Expose isometric capture function for PDF export
    if (captureRef) captureRef.current = () => {
      const savedTheta = orbit.theta, savedPhi = orbit.phi, savedRadius = orbit.radius;
      // True isometric: camera at equal X, Y, Z distance → phi = acos(1/√3) ≈ 54.74°
      orbit.theta  = -Math.PI * 0.75;
      orbit.phi    = Math.acos(1 / Math.sqrt(3));
      orbit.radius = maxDim * 2.2;
      updateCamera();
      renderer.render(scene, camera);
      const dataURL = renderer.domElement.toDataURL('image/png');
      orbit.theta = savedTheta; orbit.phi = savedPhi; orbit.radius = savedRadius;
      updateCamera();
      return dataURL;
    };

    return () => {
      cancelAnimationFrame(animId);
      ro.disconnect();
      canvas.removeEventListener('mousedown', onDown);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      canvas.removeEventListener('wheel', onWheel);
      if (el.contains(canvas)) el.removeChild(canvas);
      renderer.dispose();
    };
  }, []);

  // ── FACE HIGHLIGHT UPDATE ──
  React.useEffect(() => {
    const t = threeRef.current;
    if (!t.faceMeshes) return;
    selectedRef.current = selectedFaceIdxs;
    const hasSelection = selectedFaceIdxs.length > 0;
    const selSet = new Set(selectedFaceIdxs);
    // Determine fixture face set (for coloring when no dfm selection)
    const fixSet = new Set(activeFixture ? activeFixture.face_idxs : []);

    // Workholding: only the BEST (first) rest face and BEST (first) clamp pair.
    // A machinist picks one datum surface and one vise pair, not all candidates.
    const restSet  = new Set();
    const clampSet = new Set();
    if (activeFixture && activeFixture.workholding) {
      const wh = activeFixture.workholding;
      if (wh.rest_faces && wh.rest_faces.length > 0) {
        restSet.add(wh.rest_faces[0].face_idx);
      }
      if (wh.clamp_pairs && wh.clamp_pairs.length > 0) {
        clampSet.add(wh.clamp_pairs[0].face_idx_a);
        clampSet.add(wh.clamp_pairs[0].face_idx_b);
      }
    }

    Object.entries(t.faceMeshes).forEach(([idxStr, mesh]) => {
      const idx = parseInt(idxStr);
      if (hasSelection) {
        // DFM selection active: orange for selected, workholding colors, fixture blue, rest dimmed
        if (selSet.has(idx))         mesh.material = t.MAT_HIGHLIGHT();
        else if (restSet.has(idx))   mesh.material = t.MAT_REST();
        else if (clampSet.has(idx))  mesh.material = t.MAT_CLAMP();
        else if (fixSet.has(idx))    mesh.material = t.MAT_FIXTURE();
        else                         mesh.material = t.MAT_DIM();
      } else if (activeFixture) {
        // Fixture active, no DFM selection: workholding colors, fixture blue, rest dimmed
        if (restSet.has(idx))        mesh.material = t.MAT_REST();
        else if (clampSet.has(idx))  mesh.material = t.MAT_CLAMP();
        else if (fixSet.has(idx))    mesh.material = t.MAT_FIXTURE();
        else                         mesh.material = t.MAT_DIM();
      } else {
        mesh.material = t.MAT_DEFAULT();
      }
    });
  }, [selectedFaceIdxs, activeFixture]);

  // ── FIXTURE ARROW + EDGE WIREFRAME ──
  React.useEffect(() => {
    const t = threeRef.current;
    if (!t.scene) return;

    // Remove previous arrow
    if (arrowRef.current) { t.scene.remove(arrowRef.current); arrowRef.current = null; }
    // Remove previous edge overlays
    edgesRef.current.forEach(l => t.scene.remove(l));
    edgesRef.current = [];

    if (!activeFixture) return;

    const { center, maxDim } = t;
    const [ax, ay, az] = activeFixture.approach_vector;
    const mag = Math.sqrt(ax*ax + ay*ay + az*az) || 1;
    const dir = new THREE.Vector3(ax/mag, ay/mag, az/mag);

    // Arrow — positioned outside the part on the approach side, pointing toward part
    const arrowLen  = maxDim * 0.45;
    const arrowFrom = center.clone().addScaledVector(dir, maxDim * 1.05);
    const arrowDir  = dir.clone().negate();
    const arrow = new THREE.ArrowHelper(arrowDir, arrowFrom, arrowLen, 0x2563eb, arrowLen * 0.28, arrowLen * 0.18);
    // Make shaft and head thicker for visibility
    arrow.line.material.linewidth = 3;
    t.scene.add(arrow);
    arrowRef.current = arrow;

    // Edge wireframes for every face in this fixturing
    const fixSet = new Set(activeFixture.face_idxs);
    // Only the BEST rest face and BEST clamp pair — matches highlight logic
    const restSet  = new Set();
    const clampSet = new Set();
    if (activeFixture.workholding) {
      const wh = activeFixture.workholding;
      if (wh.rest_faces && wh.rest_faces.length > 0) {
        restSet.add(wh.rest_faces[0].face_idx);
      }
      if (wh.clamp_pairs && wh.clamp_pairs.length > 0) {
        clampSet.add(wh.clamp_pairs[0].face_idx_a);
        clampSet.add(wh.clamp_pairs[0].face_idx_b);
      }
    }

    R.geometry.forEach(fd => {
      const inFix   = fixSet.has(fd.i);
      const inRest  = restSet.has(fd.i);
      const inClamp = clampSet.has(fd.i);
      if (!inFix && !inRest && !inClamp) return;
      try {
        const geo  = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(fd.v), 3));
        geo.setIndex(fd.t);
        const edgeGeo = new THREE.EdgesGeometry(geo, 15);  // crease angle 15°
        // Color: green for rest, amber for clamp, blue for fixture
        const edgeColor = inRest ? 0x059669 : inClamp ? 0xb45309 : 0x1d4ed8;
        const mat = new THREE.LineBasicMaterial({ color: edgeColor, linewidth: 2 });
        const lines = new THREE.LineSegments(edgeGeo, mat);
        t.scene.add(lines);
        edgesRef.current.push(lines);
      } catch(e) {}
    });
  }, [activeFixture]);

  const dotColor = SEV_COLOR[labelSev] || "#374151";

  return (
    <div style={{ position: "relative", width: "100%", height: "100%", background: "#f8f8f8" }}>
      <div ref={containerRef} style={{ width: "100%", height: "100%" }} />

      <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", overflow: "visible" }}>
        <line ref={svgLineRef} stroke="#9ca3af" strokeWidth="1.5" strokeDasharray="5,3" display="none" />
        <circle ref={svgDotRef} r="5" fill={dotColor} stroke="#fff" strokeWidth="1.5" display="none" />
      </svg>

      {labelText && selectedFaceIdxs.length > 0 && (
        <div style={{
          position: "absolute", bottom: 10, left: 10,
          background: "#fff", border: `1.5px solid ${SEV_BORDER[labelSev] || "#e5e7eb"}`,
          borderLeft: `3px solid ${SEV_COLOR[labelSev] || "#374151"}`,
          borderRadius: 5, padding: "8px 12px",
          maxWidth: 260, boxShadow: "0 2px 8px rgba(0,0,0,0.12)", pointerEvents: "none",
        }}>
          <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: "0.12em", color: SEV_COLOR[labelSev], textTransform: "uppercase", marginBottom: 3 }}>{SEV_LABEL[labelSev] || "INFO"}</div>
          <div style={{ fontSize: 11, color: "#374151", lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>{labelText}</div>
        </div>
      )}

      {activeFixture && !labelText && (
        <div style={{ position: "absolute", bottom: 10, left: 10, background: "rgba(255,255,255,0.95)", border: "1px solid rgba(37,99,235,0.25)", borderLeft: "3px solid #2563eb", borderRadius: 5, padding: "7px 12px", pointerEvents: "none", maxWidth: 280 }}>
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.12em", color: "#2563eb", textTransform: "uppercase", marginBottom: 2 }}>FIXTURING {activeFixture.label}</div>
          <div style={{ fontSize: 10, color: "#374151", marginBottom: 4 }}>
            {activeFixture.face_idxs.length} surfaces assigned · approach {activeFixture.label}
            {activeFixture.setup_type && (
              <span style={{
                display: "inline-block", marginLeft: 6, fontSize: 8, fontWeight: 600,
                padding: "1px 5px", borderRadius: 3, verticalAlign: "middle",
                background: activeFixture.setup_type.includes("5-axis") ? "#fef3c7" : "#f0fdf4",
                color: activeFixture.setup_type.includes("5-axis") ? "#92400e" : "#15803d",
                border: `1px solid ${activeFixture.setup_type.includes("5-axis") ? "#fde68a" : "#bbf7d0"}`,
                letterSpacing: "0.04em", textTransform: "uppercase",
              }}>
                {activeFixture.setup_type.replace(/-/g, " ")}
              </span>
            )}
            {(() => {
              const [ax, ay, az] = activeFixture.approach_vector;
              const mag = Math.sqrt(ax*ax + ay*ay + az*az) || 1;
              const nx = ax/mag, ny = ay/mag, nz = az/mag;
              // Check if non-principal (label starts with "fix" or has no ± axis prefix)
              const isPrincipal = /^[+-][XYZ]$/.test(activeFixture.label);
              if (isPrincipal) return null;
              // Compute angles from each principal axis
              const toDeg = r => (r * 180 / Math.PI).toFixed(1);
              const angX = toDeg(Math.acos(Math.abs(nx)));
              const angY = toDeg(Math.acos(Math.abs(ny)));
              const angZ = toDeg(Math.acos(Math.abs(nz)));
              return (
                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, color: "#6b7280", marginTop: 3 }}>
                  {angX}° from X · {angY}° from Y · {angZ}° from Z
                  <br />
                  vector ({nx.toFixed(3)}, {ny.toFixed(3)}, {nz.toFixed(3)})
                </div>
              );
            })()}
          </div>
          {activeFixture.workholding && (
            <div style={{ borderTop: "1px solid #e5e7eb", paddingTop: 4, marginTop: 2 }}>
              <div style={{ fontSize: 9, fontWeight: 600, color: "#6b7280", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 3 }}>WORKHOLDING: {activeFixture.workholding.class.replace(/_/g, " ")}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 2, background: "#34d399", border: "1px solid #059669", flexShrink: 0 }} />
                  <span style={{ fontSize: 9, color: "#374151" }}>Rest / datum face{activeFixture.workholding.rest_faces && activeFixture.workholding.rest_faces.length > 0 ? "" : " — none"}</span>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 2, background: "#fbbf24", border: "1px solid #b45309", flexShrink: 0 }} />
                  <span style={{ fontSize: 9, color: "#374151" }}>Clamp faces{activeFixture.workholding.clamp_pairs && activeFixture.workholding.clamp_pairs.length > 0 ? "" : " — none"}</span>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 2, background: "#c7d8f5", border: "1px solid #1d4ed8", flexShrink: 0 }} />
                  <span style={{ fontSize: 9, color: "#374151" }}>Machined surfaces</span>
                </div>
              </div>
              {activeFixture.workholding.warnings && activeFixture.workholding.warnings.length > 0 && (
                <div style={{ marginTop: 4, paddingTop: 3, borderTop: "1px solid #fde68a" }}>
                  {activeFixture.workholding.warnings.map((w, i) => (
                    <div key={i} style={{ fontSize: 8, color: "#92400e", lineHeight: 1.4, marginBottom: 1 }}>⚠ {w}</div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {!HAS_GEO && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 8 }}>
          <div style={{ fontSize: 11, color: "#9ca3af", fontFamily: "'JetBrains Mono', monospace" }}>NO GEOMETRY</div>
          <div style={{ fontSize: 10, color: "#c0c0c0" }}>STEP tessellation unavailable</div>
        </div>
      )}

      {(selectedFaceIdxs.length > 0 || activeFixture) && onDeselect && (
        <button
          onClick={onDeselect}
          title="Clear selection"
          style={{
            position: "absolute", top: 10, right: 10,
            width: 28, height: 28, borderRadius: 5,
            background: "rgba(255,255,255,0.9)", border: "1px solid #d1d5db",
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14, color: "#6b7280", boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
          }}
        >✕</button>
      )}
    </div>
  );
}

// ── MAIN APP ──────────────────────────────────────────────────────────────────
function App() {
  const crits = R.dfm.filter(d => d.severity === "critical").length;
  const warns = R.dfm.filter(d => d.severity === "warning").length;
  const advs  = R.dfm.filter(d => d.severity === "advisory").length;
  const totalFlags = crits + warns + advs;
  const flagColor = crits > 0 ? SEV_COLOR.critical : warns > 0 ? SEV_COLOR.warning : "#16a34a";

  const [selectedFaceIdxs, setSelectedFaceIdxs] = React.useState([]);
  const [labelText, setLabelText] = React.useState("");
  const [labelSev,  setLabelSev]  = React.useState("advisory");
  const [activeFixture, setActiveFixture] = React.useState(null);
  const [snappedFixId, setSnappedFixId]   = React.useState(null);
  const snapRef    = React.useRef(null);
  const captureRef = React.useRef(null);
  const onOrbitRef = React.useRef(null);
  const [pdfBusy, setPdfBusy] = React.useState(false);

  // Clear snapped state when user manually orbits/pans/zooms
  onOrbitRef.current = () => setSnappedFixId(null);

  function deselectAll() {
    setSelectedFaceIdxs([]); setLabelText(""); setLabelSev("advisory");
    setActiveFixture(null); setSnappedFixId(null);
  }

  async function buildPDF() {
    if (pdfBusy) return;
    setPdfBusy(true);
    try {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });
      const PW = 210, PH = 297, ML = 15, MR = 15, MT = 15;
      const CW = PW - ML - MR;  // 180mm

      let y = MT;

      // ── HEADER ──────────────────────────────────────────────────────────────
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(107, 114, 128);
      doc.text('FACET — PART ANALYSIS REPORT', ML, y + 5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6);
      doc.text('MACHINE TYPE', PW - MR, y + 3, { align: 'right' });
      doc.setFont('courier', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(26, 26, 26);
      doc.text(R.machine_classification.replace(/-/g, ' '), PW - MR, y + 9, { align: 'right' });

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.setTextColor(26, 26, 26);
      doc.text(R.filename, ML, y + 15);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(156, 163, 175);
      doc.text(new Date(R.analyzed_at).toLocaleString('en-US', { dateStyle: 'long', timeStyle: 'short' }), ML, y + 21);

      y += 26;
      doc.setDrawColor(26, 26, 26);
      doc.setLineWidth(0.5);
      doc.line(ML, y, PW - MR, y);
      y += 7;

      // ── ISOMETRIC PART IMAGE ─────────────────────────────────────────────────
      if (HAS_GEO && captureRef.current) {
        const imgData = captureRef.current();
        const imgH = 78;
        doc.addImage(imgData, 'PNG', ML, y, CW, imgH, undefined, 'FAST');
        // Border around image
        doc.setDrawColor(229, 227, 223);
        doc.setLineWidth(0.3);
        doc.rect(ML, y, CW, imgH);
        y += imgH + 7;
      }

      // ── STAT STRIP ───────────────────────────────────────────────────────────
      const statCells = [
        { label: 'SETUPS REQUIRED', value: String(R.fixturing_count), sub: 'fixturings' },
        { label: 'BOUNDING BOX',    value: `${R.bounding_box.x} × ${R.bounding_box.y} × ${R.bounding_box.z}`, sub: `${R.unit_label}  X · Y · Z` },
        { label: 'HOLES',           value: String(R.holes.length), sub: `${R.holes.filter(h=>h.type.startsWith('blind')).length} blind · ${R.holes.filter(h=>h.type.startsWith('through')).length} through` },
        { label: 'PLANAR FACES',    value: String(R.planar_faces), sub: 'flat surfaces' },
        { label: 'MATERIAL REMOVED',value: `${R.material_removal_pct}%`, sub: R.display_unit === 'inch' ? `${(R.machined_volume_mm3/16387.1).toFixed(3)} in³ of ${(R.bbox_volume_mm3/16387.1).toFixed(3)} in³` : `${(R.machined_volume_mm3/1000).toFixed(1)} cm³ of ${(R.bbox_volume_mm3/1000).toFixed(1)} cm³`, accent: R.material_removal_pct > 70 ? [217,119,6] : [26,26,26] },
        { label: 'DFM FLAGS',        value: String(totalFlags), sub: totalFlags === 0 ? 'no issues' : `${crits} crit · ${warns} warn · ${advs} adv`, accent: crits > 0 ? [192,57,43] : warns > 0 ? [217,119,6] : [22,163,74] },
      ];

      const cellW = CW / 3, cellH = 20;
      statCells.forEach((cell, idx) => {
        const col = idx % 3, row = Math.floor(idx / 3);
        const cx = ML + col * cellW, cy = y + row * cellH;
        doc.setFillColor(255, 255, 255);
        doc.rect(cx, cy, cellW, cellH, 'F');
        doc.setDrawColor(229, 227, 223);
        doc.setLineWidth(0.25);
        doc.rect(cx, cy, cellW, cellH, 'S');
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(6);
        doc.setTextColor(156, 163, 175);
        doc.text(cell.label, cx + 3, cy + 5);
        doc.setFont('courier', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(...(cell.accent || [26, 26, 26]));
        doc.text(String(cell.value), cx + 3, cy + 13);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(6);
        doc.setTextColor(156, 163, 175);
        doc.text(cell.sub, cx + 3, cy + 18);
      });
      y += cellH * 2 + 8;

      // ── SETUP SUMMARY + HOLE INVENTORY (side by side) ─────────────────────────
      const colW = (CW - 6) / 2;
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(107, 114, 128);
      doc.text('SETUP SUMMARY', ML, y);
      doc.text('HOLE INVENTORY', ML + colW + 6, y);
      y += 5;

      const rowH = 7;
      const hdrH = 6;
      let yL = y, yR = y;

      // — Setup header —
      doc.setFillColor(248, 247, 244);
      doc.rect(ML, yL, colW, hdrH, 'F');
      doc.setDrawColor(229, 227, 223);
      doc.setLineWidth(0.2);
      doc.rect(ML, yL, colW, hdrH, 'S');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(5.5);
      doc.setTextColor(156, 163, 175);
      ['AXIS','FEATURES','H','F','FLAGS'].forEach((h, i) => {
        const xs = [ML+2, ML+14, ML+colW-18, ML+colW-11, ML+colW-2];
        doc.text(h, xs[i], yL + 4, i === 4 ? { align: 'right' } : {});
      });
      yL += hdrH;

      // — Setup rows —
      R.fixturings.forEach((f, i) => {
        const tc = f.concerns.critical + f.concerns.warning + f.concerns.advisory;
        const fRgb = f.concerns.critical > 0 ? [192,57,43] : f.concerns.warning > 0 ? [217,119,6] : tc > 0 ? [107,114,128] : [156,163,175];
        doc.setFillColor(i%2===0 ? 255:250, i%2===0 ? 255:250, i%2===0 ? 255:250);
        doc.rect(ML, yL, colW, rowH, 'F');
        doc.setDrawColor(240, 237, 233);
        doc.rect(ML, yL, colW, rowH, 'S');
        doc.setFont('courier', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(26, 26, 26);
        doc.text(f.label, ML + 2, yL + 5);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(5.5);
        doc.setTextColor(107, 114, 128);
        const feats = [f.planar>0&&`${f.planar}pl`, f.holes>0&&`${f.holes}h`, `~${f.tool_changes}tc`].filter(Boolean).join(' · ');
        doc.text(feats, ML + 14, yL + 5);
        doc.setFont('courier', 'normal');
        doc.setFontSize(7);
        doc.setTextColor(26, 26, 26);
        doc.text(String(f.holes),  ML + colW - 18, yL + 5);
        doc.text(String(f.planar), ML + colW - 11, yL + 5);
        doc.setFont('courier', tc > 0 ? 'bold' : 'normal');
        doc.setTextColor(...fRgb);
        doc.text(tc > 0 ? String(tc) : '—', ML + colW - 2, yL + 5, { align: 'right' });
        yL += rowH;
      });

      // — Hole header —
      const hx = ML + colW + 6;
      doc.setFillColor(248, 247, 244);
      doc.rect(hx, yR, colW, hdrH, 'F');
      doc.setDrawColor(229, 227, 223);
      doc.rect(hx, yR, colW, hdrH, 'S');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(5.5);
      doc.setTextColor(156, 163, 175);
      doc.text('TYPE', hx + 2, yR + 4);
      doc.text(`⌀ (${R.unit_label})`, hx + colW - 24, yR + 4);
      doc.text('DEPTH', hx + colW - 14, yR + 4);
      doc.text('L/D', hx + colW - 2, yR + 4, { align: 'right' });
      yR += hdrH;

      // — Hole rows —
      const HOLE_LABELS_PDF = { through:'Through', through_counterbore:'Counterbore', through_countersink:'Countersink', blind_flat:'Blind (flat)', blind_with_tip:'Blind (tip)' };
      R.holes.forEach((h, i) => {
        doc.setFillColor(i%2===0 ? 255:250, i%2===0 ? 255:250, i%2===0 ? 255:250);
        doc.rect(hx, yR, colW, rowH, 'F');
        doc.setDrawColor(240, 237, 233);
        doc.rect(hx, yR, colW, rowH, 'S');
        const isBlind = h.type.startsWith('blind');
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(6.5);
        doc.setTextColor(...(isBlind ? [146,64,14] : [20,83,45]));
        doc.text(HOLE_LABELS_PDF[h.type] || h.type, hx + 2, yR + 5);
        doc.setFont('courier', 'normal');
        doc.setFontSize(7);
        doc.setTextColor(55, 65, 81);
        doc.text((h.radius*2).toFixed(R.display_unit==='inch'?4:2), hx + colW - 24, yR + 5);
        doc.text(h.depth.toFixed(R.display_unit==='inch'?4:1), hx + colW - 14, yR + 5);
        const ldRgb = !h.ld ? [156,163,175] : h.ld >= 6 ? [192,57,43] : h.ld >= 4 ? [217,119,6] : [55,65,81];
        doc.setTextColor(...ldRgb);
        doc.setFont('courier', h.ld >= 4 ? 'bold' : 'normal');
        doc.text(h.ld ? `${h.ld}:1` : '—', hx + colW - 2, yR + 5, { align: 'right' });
        yR += rowH;
      });

      y = Math.max(yL, yR) + 10;

      // ── DFM FLAGS ────────────────────────────────────────────────────────────
      if (y > PH - 50) { doc.addPage(); y = MT; }

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(107, 114, 128);
      doc.text('MANUFACTURING FLAGS', ML, y);
      y += 5;

      const SEV_BG_PDF  = { critical:[254,242,242], warning:[255,251,235], advisory:[249,250,251] };
      const SEV_RGB_PDF = { critical:[192,57,43],   warning:[217,119,6],   advisory:[107,114,128] };

      if (totalFlags === 0) {
        doc.setFillColor(240, 253, 244);
        doc.rect(ML, y, CW, 8, 'F');
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(21, 128, 61);
        doc.text('No manufacturing flags — part appears suitable for standard CNC machining.', ML + 4, y + 5.5);
      } else {
        groups.forEach(g => {
          if (y > PH - 20) { doc.addPage(); y = MT; }
          const sev = g.severity;
          const label = CODE_LABELS[g.code] || g.code.replace(/_/g, ' ');
          // Group header
          doc.setFillColor(...SEV_BG_PDF[sev]);
          doc.rect(ML, y, CW, 7, 'F');
          doc.setDrawColor(...SEV_RGB_PDF[sev]);
          doc.setLineWidth(0.8);
          doc.line(ML, y, ML, y + 7);
          doc.setDrawColor(229, 227, 223);
          doc.setLineWidth(0.2);
          doc.rect(ML, y, CW, 7, 'S');
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(6);
          doc.setTextColor(...SEV_RGB_PDF[sev]);
          doc.text(sev.toUpperCase(), ML + 3, y + 4.5);
          doc.setFontSize(7);
          doc.setTextColor(55, 65, 81);
          doc.text(label, ML + 22, y + 4.5);
          if (g.items.length > 1) {
            doc.setFont('courier', 'bold');
            doc.setFontSize(7);
            doc.setTextColor(...SEV_RGB_PDF[sev]);
            doc.text(`×${g.items.length}`, ML + CW - 2, y + 4.5, { align: 'right' });
          }
          y += 7;
          // Item rows
          g.items.forEach((item, i) => {
            if (y > PH - 12) { doc.addPage(); y = MT; }
            doc.setFillColor(i%2===0 ? 255:250, i%2===0 ? 255:250, i%2===0 ? 255:250);
            doc.rect(ML, y, CW, 6, 'F');
            doc.setDrawColor(229, 227, 223);
            doc.setLineWidth(0.2);
            doc.rect(ML, y, CW, 6, 'S');
            doc.setFont('courier', 'normal');
            doc.setFontSize(6);
            doc.setTextColor(156, 163, 175);
            doc.text(`Fix. ${item.fixturing}`, ML + 3, y + 4);
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(6.5);
            doc.setTextColor(55, 65, 81);
            const msgLine = doc.splitTextToSize(item.message, CW - 25)[0];
            doc.text(msgLine, ML + 22, y + 4);
            y += 6;
          });
          y += 2;
        });
      }

      // Footer
      doc.setFont('courier', 'normal');
      doc.setFontSize(7);
      doc.setTextColor(209, 205, 199);
      doc.text(R.filename, PW - MR, PH - 8, { align: 'right' });

      doc.save(`${R.filename.replace(/\.[^.]+$/, '')}_facet_report.pdf`);
    } finally {
      setPdfBusy(false);
    }
  }

  function buildExcel() {
    const XLSX = window.XLSX;
    if (!XLSX) { alert("SheetJS not loaded"); return; }
    const wb = XLSX.utils.book_new();

    // ── Sheet 1: Summary ──
    const summary = [
      ["Facet — Part Analysis Report"],
      ["File", R.filename],
      ["Date", new Date(R.analyzed_at).toLocaleString()],
      ["Machine Classification", R.machine_classification],
      ["Display Unit", R.display_unit],
      [],
      ["Bounding Box"],
      ["X", R.bounding_box.x, R.unit_label],
      ["Y", R.bounding_box.y, R.unit_label],
      ["Z", R.bounding_box.z, R.unit_label],
      [],
      ["Volumes"],
      ["Bounding Box", R.bbox_volume_mm3, "mm³"],
      ["Solid", R.solid_volume_mm3, "mm³"],
      ["Machined", R.machined_volume_mm3, "mm³"],
      ["Material Removal", R.material_removal_pct, "%"],
      [],
      ["Counts"],
      ["Setups", R.fixturing_count],
      ["Planar Faces", R.planar_faces],
      ["Total Holes", R.holes ? R.holes.length : 0],
      ["DFM Flags", R.dfm ? R.dfm.length : 0],
    ];
    const wsSummary = XLSX.utils.aoa_to_sheet(summary);
    wsSummary["!cols"] = [{ wch: 22 }, { wch: 18 }, { wch: 8 }];
    XLSX.utils.book_append_sheet(wb, wsSummary, "Summary");

    // ── Sheet 2: Setups ──
    const setupRows = [["Fixture", "Axis", "Setup Type", "Holes", "Planar Faces", "Floors", "Walls", "Tool Changes", "Min Tool Dia", "Workholding", "Critical", "Warning", "Advisory"]];
    R.fixturings.forEach(f => {
      setupRows.push([
        f.id + 1,
        f.label,
        f.setup_type,
        f.holes || 0,
        f.planar || 0,
        f.floor || 0,
        f.wall || 0,
        f.tool_changes || 0,
        f.min_tool_dia || "",
        f.workholding ? f.workholding.class : "",
        f.concerns ? f.concerns.critical : 0,
        f.concerns ? f.concerns.warning : 0,
        f.concerns ? f.concerns.advisory : 0,
      ]);
    });
    const wsSetups = XLSX.utils.aoa_to_sheet(setupRows);
    wsSetups["!cols"] = [{ wch: 8 }, { wch: 8 }, { wch: 22 }, { wch: 8 }, { wch: 12 }, { wch: 8 }, { wch: 8 }, { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 8 }, { wch: 8 }, { wch: 8 }];
    XLSX.utils.book_append_sheet(wb, wsSetups, "Setups");

    // ── Sheet 3: Holes ──
    const holeRows = [["ID", "Type", "Thread", `Diameter (${R.unit_label})`, `Depth (${R.unit_label})`, "L/D", "Cone Angle"]];
    (R.holes || []).forEach(h => {
      holeRows.push([
        h.id,
        h.type,
        h.thread || "",
        +(h.radius * 2).toFixed(4),
        +h.depth.toFixed(4),
        h.ld ? +h.ld.toFixed(1) : "",
        h.cone_angle || "",
      ]);
    });
    const wsHoles = XLSX.utils.aoa_to_sheet(holeRows);
    wsHoles["!cols"] = [{ wch: 6 }, { wch: 20 }, { wch: 12 }, { wch: 14 }, { wch: 14 }, { wch: 8 }, { wch: 10 }];
    XLSX.utils.book_append_sheet(wb, wsHoles, "Holes");

    // ── Sheet 4: DFM Flags ──
    const dfmRows = [["Severity", "Category", "Fixture", "Message"]];
    (R.dfm || []).forEach(d => {
      dfmRows.push([d.severity, d.code, d.fixturing, d.message]);
    });
    const wsDfm = XLSX.utils.aoa_to_sheet(dfmRows);
    wsDfm["!cols"] = [{ wch: 10 }, { wch: 20 }, { wch: 8 }, { wch: 80 }];
    XLSX.utils.book_append_sheet(wb, wsDfm, "DFM Flags");

    // ── Sheet 5: Drawing Info (if present) ──
    if (R.drawing && R.drawing.has_drawing) {
      const drawRows = [
        ["Drawing Analysis"],
        [],
        ["Material", R.drawing.material || ""],
        ["Tightest Tolerance", R.drawing.tightest_tolerance != null ? (["position","flatness","perpendicularity","parallelism","concentricity","cylindricity","straightness","runout","total_runout","circular_runout","profile","profile_of_surface","profile_of_line","angularity","symmetry"].includes((R.drawing.tightest_tolerance_type||"").replace(/ /g,"_")) ? `${R.drawing.tightest_tolerance}` : `±${R.drawing.tightest_tolerance}`) : ""],
        ["Tolerance Type", R.drawing.tightest_tolerance_type || ""],
        ["Datums", (R.drawing.datums || []).join(", ")],
        ["Surface Finish (General)", (R.drawing.surface_finish_general || []).join(", ")],
        ["Surface Finish (Individual)", (R.drawing.surface_finish_individual || []).join(", ")],
        ["Confidence", R.drawing.confidence || ""],
      ];

      if (R.drawing.gdt && R.drawing.gdt.length > 0) {
        drawRows.push([], ["GD&T Callouts"]);
        drawRows.push(["Type", "Tolerance", "Datums"]);
        R.drawing.gdt.forEach(g => {
          drawRows.push([g.type, g.tolerance, (g.datums || []).join(" ")]);
        });
      }

      if (R.drawing.inline_tolerances && R.drawing.inline_tolerances.length > 0) {
        drawRows.push([], ["Specific Tolerances"]);
        drawRows.push(["Nominal", "Plus", "Minus", "Type"]);
        R.drawing.inline_tolerances.forEach(t => {
          drawRows.push([t.nominal, t.plus, t.minus, t.type || ""]);
        });
      }

      if (R.drawing.general_tolerances) {
        drawRows.push([], ["General Tolerance Block"]);
        drawRows.push(["Decimal Places", "Tolerance"]);
        Object.entries(R.drawing.general_tolerances).filter(([k]) => !isNaN(k)).sort(([a],[b]) => a - b).forEach(([places, val]) => {
          drawRows.push(["." + "X".repeat(Number(places)), `±${val}`]);
        });
      }

      if (R.drawing.process_notes && R.drawing.process_notes.length > 0) {
        drawRows.push([], ["Process Notes"]);
        drawRows.push(["Category", "Note"]);
        R.drawing.process_notes.forEach(n => {
          drawRows.push([n.category, n.text]);
        });
      }

      const wsDraw = XLSX.utils.aoa_to_sheet(drawRows);
      wsDraw["!cols"] = [{ wch: 24 }, { wch: 18 }, { wch: 12 }, { wch: 12 }];
      XLSX.utils.book_append_sheet(wb, wsDraw, "Drawing");
    }

    XLSX.writeFile(wb, `${R.filename.replace(/\.[^.]+$/, '')}_facet_report.xlsx`);
  }

  function selectFaces(faceIdxs, text, sev) {
    if (JSON.stringify(faceIdxs.sort()) === JSON.stringify([...selectedFaceIdxs].sort())) {
      setSelectedFaceIdxs([]); setLabelText(""); setLabelSev("advisory");
    } else {
      setSelectedFaceIdxs(faceIdxs); setLabelText(text); setLabelSev(sev);
    }
  }

  function toggleFixture(fix) {
    if (activeFixture && activeFixture.id === fix.id) {
      setActiveFixture(null);
      setSnappedFixId(null);
    } else {
      setActiveFixture(fix);
      setSelectedFaceIdxs([]); setLabelText(""); setLabelSev("advisory");
    }
  }

  function snapToFixture(fix) {
    if (snapRef.current) snapRef.current(fix.approach_vector);
    setSnappedFixId(fix.id);
  }

  // ── DFM flag grouping ──
  const SEV_RANK = { critical: 0, warning: 1, advisory: 2 };
  const CODE_LABELS = {
    hole_ld:                  "Deep Hole (L/D)",
    small_hole:               "Small Hole",
    ball_nose_required:       "Ball Nose Required",
    concave_fillet_tool_dia:  "Concave Fillet Tool",
    sharp_internal_corner:    "Sharp Internal Corner",
    deep_feature:             "Deep Feature",
    thin_wall:                "Thin Wall",
    thin_wall_hole_proximity: "Thin Wall — Hole Proximity",
    partial_hole:             "Partial / Intersected Hole",
    no_datum_face:            "No Datum Face",
    datum_face_features:      "Datum Face Has Features",
    cog_instability:          "Centre of Gravity Instability",
    no_clamp_pair:            "No Vise Clamping Pair",
    clamp_face_features:      "Clamp Face Has Features",
    custom_fixture:           "Custom Fixture Required",
  };
  const groups = [];
  const seen = {};
  for (const d of R.dfm) {
    if (!seen[d.code]) { seen[d.code] = { code: d.code, severity: d.severity, items: [] }; groups.push(seen[d.code]); }
    if (SEV_RANK[d.severity] < SEV_RANK[seen[d.code].severity]) seen[d.code].severity = d.severity;
    seen[d.code].items.push(d);
  }
  const [expanded, setExpanded] = React.useState({});
  const toggle = (code) => setExpanded(e => ({ ...e, [code]: !e[code] }));

  function SectionHead({ children }) {
    return <div style={{ fontSize: 11, fontWeight: 500, letterSpacing: "0.08em", textTransform: "uppercase", color: "#2563eb", marginBottom: 10 }}>{children}</div>;
  }

  const isActiveFlag = (items) => items.some(d => d.face_idxs && d.face_idxs.length > 0 && JSON.stringify(d.face_idxs.slice().sort()) === JSON.stringify([...selectedFaceIdxs].sort()));
  const isActiveHole = (h) => h.face_idxs && h.face_idxs.length > 0 && JSON.stringify(h.face_idxs.slice().sort()) === JSON.stringify([...selectedFaceIdxs].sort());

  return (
    <div style={{ background: "#ffffff", minHeight: "100vh", fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif", color: "#111111" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .clickable-row:hover { background: #f8f8f8 !important; cursor: pointer; }
        .clickable-row.active { background: #eff4ff !important; outline: 1px solid #bfdbfe; }
        @media print { .viewer-card { display: none; } body { background: white; } }
      `}</style>

      <div style={{ maxWidth: 860, margin: "0 auto", padding: "40px 40px 60px" }}>

        {/* HEADER */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28, paddingBottom: 20, borderBottom: "1px solid #e4e4e4" }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 500, letterSpacing: "0.08em", color: "#2563eb", marginBottom: 6, textTransform: "uppercase" }}>Facet — Part Analysis Report</div>
            <div style={{ fontSize: 22, fontWeight: 600, color: "#111111", letterSpacing: "-0.01em", marginBottom: 3 }}>{R.filename}</div>
            <div style={{ fontSize: 11, color: "#9ca3af" }}>{new Date(R.analyzed_at).toLocaleString("en-US", { dateStyle: "long", timeStyle: "short" })}</div>
          </div>
          <div style={{ textAlign: "right", display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 12 }}>
            <div>
              <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: "0.14em", color: "#9ca3af", marginBottom: 4, textTransform: "uppercase" }}>Machine Type</div>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 500, color: "#111111" }}>{R.machine_classification.replace(/-/g, " ")}</div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button
                onClick={buildExcel}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "8px 16px", borderRadius: 5, cursor: "pointer",
                  background: "#fff", color: "#111111",
                  border: "1px solid #e4e4e4", fontFamily: "'JetBrains Mono', monospace",
                  fontSize: 11, fontWeight: 500, letterSpacing: "0.04em",
                }}
              >
                <span style={{ fontSize: 13 }}>↓</span>
                EXPORT XLSX
              </button>
              <button
                onClick={buildPDF}
                disabled={pdfBusy}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "8px 16px", borderRadius: 5, cursor: pdfBusy ? "wait" : "pointer",
                  background: pdfBusy ? "#f1f5f9" : "#111111",
                  color: pdfBusy ? "#9ca3af" : "#fff",
                  border: "none", fontFamily: "'JetBrains Mono', monospace",
                  fontSize: 11, fontWeight: 500, letterSpacing: "0.04em",
                  boxShadow: pdfBusy ? "none" : "0 1px 3px rgba(0,0,0,0.18)",
                }}
              >
                <span style={{ fontSize: 13 }}>{pdfBusy ? "⏳" : "↓"}</span>
                {pdfBusy ? "GENERATING…" : "EXPORT PDF"}
              </button>
            </div>
          </div>
        </div>

        {/* STAT STRIP */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 1, marginBottom: 20, background: "#e4e4e4", borderRadius: 10, overflow: "hidden" }}>
          {[
            { label: "Setups Required", value: R.fixturing_count, sub: "fixturings" },
            { label: "Bounding Box",    value: `${R.bounding_box.x} × ${R.bounding_box.y} × ${R.bounding_box.z}`, sub: `${R.unit_label}  X · Y · Z` },
            { label: "Holes",          value: R.holes.length, sub: `${R.holes.filter(h=>h.type.startsWith("blind")).length} blind · ${R.holes.filter(h=>h.type.startsWith("through")).length} through` },
            { label: "Planar Faces",   value: R.planar_faces, sub: "flat surfaces" },
            { label: "Material Removed", value: `${R.material_removal_pct}%`, sub: R.display_unit === "inch" ? `${(R.machined_volume_mm3/16387.1).toFixed(3)} in³ of ${(R.bbox_volume_mm3/16387.1).toFixed(3)} in³` : `${(R.machined_volume_mm3/1000).toFixed(1)} cm³ of ${(R.bbox_volume_mm3/1000).toFixed(1)} cm³`, accent: R.material_removal_pct > 70 ? SEV_COLOR.warning : "#111111" },
            { label: "DFM Flags",      value: totalFlags, sub: totalFlags === 0 ? "no issues" : `${crits} crit · ${warns} warn · ${advs} adv`, accent: flagColor },
          ].map(({ label, value, sub, accent }) => (
            <div key={label} style={{ background: "#fff", padding: "14px 16px" }}>
              <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: "0.14em", color: "#9ca3af", textTransform: "uppercase", marginBottom: 5 }}>{label}</div>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 500, color: accent || "#111111", lineHeight: 1.2, marginBottom: 3 }}>{value}</div>
              <div style={{ fontSize: 10, color: "#9ca3af" }}>{sub}</div>
            </div>
          ))}
        </div>

        {/* INLINE 3D VIEWER */}
        {HAS_GEO && (
          <div className="viewer-card" style={{ marginBottom: 24, background: "#fff", border: "1px solid #e4e4e4", borderRadius: 10, overflow: "hidden" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 16px", background: "#f8f8f8", borderBottom: "1px solid #e4e4e4" }}>
              <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", color: "#6b7280" }}>3D View</div>
              <div style={{ fontSize: 9, color: "#999999", fontFamily: "'JetBrains Mono', monospace" }}>DRAG · SCROLL · RIGHT-DRAG PAN · CLICK FEATURES TO HIGHLIGHT</div>
            </div>
            <div style={{ height: 400 }}>
              <Viewer3D
                selectedFaceIdxs={selectedFaceIdxs}
                labelText={labelText}
                labelSev={labelSev}
                activeFixture={activeFixture}
                snapRef={snapRef}
                captureRef={captureRef}
                onOrbitRef={onOrbitRef}
                onDeselect={deselectAll}
              />
            </div>
          </div>
        )}

        {/* SETUP + HOLES TWO COLUMN */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 24 }}>

            {/* SETUPS */}
            <div>
              <SectionHead>Setup Summary {HAS_GEO && <span style={{ fontWeight: 400, letterSpacing: 0, textTransform: "none", color: "#999999", fontSize: 10 }}>— click to show axis</span>}</SectionHead>
              <div style={{ background: "#fff", border: "1px solid #e4e4e4", borderRadius: 10, overflow: "hidden" }}>
                <div style={{ display: "grid", gridTemplateColumns: "44px 1fr 38px 38px 38px 52px", padding: "7px 12px", background: "#f8f8f8", borderBottom: "1px solid #e4e4e4" }}>
                  {["Axis","Features","Holes","Faces","Flags",""].map((h, i) => (
                    <div key={i} style={{ fontSize: 9, fontWeight: 600, letterSpacing: "0.12em", color: "#9ca3af", textTransform: "uppercase", textAlign: i > 1 ? "right" : "left" }}>{h}</div>
                  ))}
                </div>
                {R.fixturings.map((f, i) => {
                  const tc = f.concerns.critical + f.concerns.warning + f.concerns.advisory;
                  const fc = f.concerns.critical > 0 ? SEV_COLOR.critical : f.concerns.warning > 0 ? SEV_COLOR.warning : f.concerns.advisory > 0 ? SEV_COLOR.advisory : "#9ca3af";
                  const isActiveFix = activeFixture && activeFixture.id === f.id;
                  return (
                    <div
                      key={f.id}
                      style={{
                        display: "grid", gridTemplateColumns: "44px 1fr 38px 38px 38px 52px",
                        padding: "10px 12px",
                        borderBottom: i < R.fixturings.length - 1 ? "1px solid #f0f0f0" : "none",
                        alignItems: "center",
                        background: isActiveFix ? "#eff6ff" : "transparent",
                        cursor: HAS_GEO ? "pointer" : "default",
                        outline: isActiveFix ? "1px solid #bfdbfe" : "none",
                      }}
                      onClick={() => HAS_GEO && toggleFixture(f)}
                    >
                      <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 500, color: isActiveFix ? "#2563eb" : "#111111" }}>{f.label}</div>
                        {isActiveFix && <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#2563eb" }} />}
                      </div>
                      <div style={{ fontSize: 10, color: "#6b7280" }}>
                        {[f.planar > 0 && `${f.planar} planar`, f.fillets > 0 && `${f.fillets} fillet${f.fillets > 1?"s":""}`, f.min_tool_dia && `⌀${f.min_tool_dia}${R.unit_label}`, `~${f.tool_changes} chg`].filter(Boolean).join(" · ")}
                        {f.workholding && (
                          <span style={{
                            marginLeft: 6, fontSize: 8, fontWeight: 600, padding: "1px 5px", borderRadius: 3, letterSpacing: "0.06em",
                            background: f.workholding.class === "vise" ? "#ecfdf5" : f.workholding.class === "toe_clamp" ? "#fffbeb" : f.workholding.class === "soft_jaw" ? "#fef3c7" : "#fef2f2",
                            color:      f.workholding.class === "vise" ? "#059669" : f.workholding.class === "toe_clamp" ? "#d97706" : f.workholding.class === "soft_jaw" ? "#b45309" : "#dc2626",
                            border:     `1px solid ${f.workholding.class === "vise" ? "#a7f3d0" : f.workholding.class === "toe_clamp" ? "#fde68a" : f.workholding.class === "soft_jaw" ? "#fcd34d" : "#fca5a5"}`,
                          }}>{f.workholding.class.replace(/_/g, " ").toUpperCase()}</span>
                        )}
                      </div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, textAlign: "right" }}>{f.holes}</div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, textAlign: "right" }}>{f.planar}</div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, fontWeight: tc > 0 ? 600 : 400, color: fc, textAlign: "right" }}>{tc || "—"}</div>
                      <div style={{ textAlign: "right" }}>
                        {HAS_GEO && (() => {
                          const isSnapped = snappedFixId === f.id;
                          return (
                            <button
                              onClick={e => { e.stopPropagation(); if (!isActiveFix) toggleFixture(f); snapToFixture(f); }}
                              title="View from tool direction"
                              style={{
                                fontFamily: "'JetBrains Mono', monospace", fontSize: 9,
                                padding: "3px 7px", borderRadius: 4, cursor: "pointer",
                                background: isSnapped ? "#2563eb" : "#f1f5f9",
                                color: isSnapped ? "#fff" : "#64748b",
                                border: isSnapped ? "1px solid #1d4ed8" : "1px solid #e2e8f0",
                              }}
                            >↗ VIEW</button>
                          );
                        })()}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* HOLES */}
            <div>
              <SectionHead>Hole Inventory {HAS_GEO && <span style={{ fontWeight: 400, letterSpacing: 0, textTransform: "none", color: "#999999", fontSize: 10 }}>— click to highlight</span>}</SectionHead>
              <div style={{ background: "#fff", border: "1px solid #e4e4e4", borderRadius: 10, overflow: "hidden" }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 58px 60px 44px", padding: "7px 12px", background: "#f8f8f8", borderBottom: "1px solid #e4e4e4" }}>
                  {["Type", `⌀ (${R.unit_label})`, "Depth", "L/D"].map((h, i) => (
                    <div key={h} style={{ fontSize: 9, fontWeight: 600, letterSpacing: "0.12em", color: "#9ca3af", textTransform: "uppercase", textAlign: i > 0 ? "right" : "left" }}>{h}</div>
                  ))}
                </div>
                {R.holes.length === 0
                  ? <div style={{ padding: "14px 12px", fontSize: 12, color: "#9ca3af" }}>No holes detected</div>
                  : R.holes.map((h, i) => {
                    const ldColor = !h.ld ? "#9ca3af" : h.ld >= 6 ? SEV_COLOR.critical : h.ld >= 4 ? SEV_COLOR.warning : "#374151";
                    const isBlind = h.type.startsWith("blind");
                    const isThread = h.type === "thread";
                    const active = isActiveHole(h);
                    const hasGeoLink = HAS_GEO && h.face_idxs && h.face_idxs.length > 0;
                    const typeLabel = isThread ? (h.thread || "Thread") : (HOLE_LABELS[h.type] || h.type);
                    const badgeBg = isThread ? "#ede9fe" : isBlind ? "#fef3c7" : "#f0fdf4";
                    const badgeColor = isThread ? "#6d28d9" : isBlind ? "#92400e" : "#14532d";
                    return (
                      <div
                        key={h.id}
                        className={hasGeoLink ? `clickable-row${active ? " active" : ""}` : ""}
                        onClick={() => hasGeoLink && selectFaces(h.face_idxs, `${typeLabel} — ⌀${(h.radius*2).toFixed(R.display_unit==="inch"?4:2)} ${R.unit_label}`, "info")}
                        style={{ display: "grid", gridTemplateColumns: "1fr 58px 60px 44px", padding: "9px 12px", borderBottom: i < R.holes.length - 1 ? "1px solid #f0f0f0" : "none", alignItems: "center" }}
                      >
                        <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                          <span style={{ fontSize: 10, fontWeight: 500, color: badgeColor, background: badgeBg, padding: "2px 6px", borderRadius: 3 }}>
                            {typeLabel}
                          </span>
                          {h.cone_angle && <span style={{ fontSize: 9, color: "#9ca3af" }}>{h.cone_angle}°</span>}
                          {h.thread_pitch && <span style={{ fontSize: 9, color: "#9ca3af" }}>pitch {h.thread_pitch}</span>}
                        </div>
                        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#374151", textAlign: "right" }}>{(h.radius * 2).toFixed(R.display_unit === "inch" ? 4 : 2)}</div>
                        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#374151", textAlign: "right" }}>{h.depth.toFixed(R.display_unit === "inch" ? 4 : 1)}</div>
                        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: ldColor, textAlign: "right", fontWeight: h.ld >= 4 ? 600 : 400 }}>{h.ld ? `${h.ld}:1` : "—"}</div>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>

          {/* DFM FLAGS */}
          {totalFlags > 0 && (
            <div>
              <SectionHead>Manufacturing Flags {HAS_GEO && <span style={{ fontWeight: 400, letterSpacing: 0, textTransform: "none", color: "#999999", fontSize: 10 }}>— click to highlight</span>}</SectionHead>
              <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                {groups.map(g => {
                  const sev   = g.severity;
                  const open  = !!expanded[g.code];
                  const label = CODE_LABELS[g.code] || g.code.replace(/_/g, " ");
                  const multi = g.items.length > 1;
                  const active = isActiveFlag(g.items);

                  return (
                    <div key={g.code} style={{ borderRadius: 5, overflow: "hidden", border: `1px solid ${SEV_BORDER[sev]}`, borderLeft: `3px solid ${SEV_COLOR[sev]}`, outline: active ? `2px solid ${SEV_COLOR[sev]}` : "none" }}>
                      {/* GROUP HEADER */}
                      <div
                        onClick={() => {
                          if (multi) toggle(g.code);
                          // If single item with face_idxs, highlight it
                          if (!multi && g.items[0].face_idxs && g.items[0].face_idxs.length > 0) {
                            selectFaces(g.items[0].face_idxs, g.items[0].message, sev);
                          }
                        }}
                        style={{
                          display: "grid", gridTemplateColumns: "80px 1fr auto auto",
                          gap: 10, alignItems: "center",
                          background: active ? (sev === "critical" ? "#fee2e2" : sev === "warning" ? "#fef3c7" : "#f3f4f6") : SEV_BG[sev],
                          padding: "10px 12px",
                          cursor: "pointer", userSelect: "none",
                        }}
                      >
                        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.12em", color: SEV_COLOR[sev], textTransform: "uppercase" }}>{SEV_LABEL[sev]}</div>
                        <div style={{ fontSize: 12, color: "#374151", lineHeight: 1.45 }}>
                          <span style={{ fontWeight: 500 }}>{label}</span>
                          {!multi && <span style={{ color: "#6b7280", marginLeft: 7, fontFamily: "'JetBrains Mono', monospace", fontSize: 10 }}>Fix. {g.items[0].fixturing}</span>}
                          {!open && multi && <span style={{ color: "#9ca3af", marginLeft: 7, fontSize: 11 }}>— {g.items[0].message.length > 65 ? g.items[0].message.slice(0,65)+"…" : g.items[0].message}</span>}
                        </div>
                        {multi && <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: SEV_COLOR[sev], background: SEV_BORDER[sev], padding: "2px 6px", borderRadius: 3, whiteSpace: "nowrap" }}>{g.items.length}</span>}
                        {multi && <span style={{ fontSize: 11, color: "#9ca3af", width: 14, textAlign: "center" }}>{open ? "▲" : "▼"}</span>}
                      </div>
                      {/* EXPANDED ITEMS */}
                      {open && multi && (
                        <div style={{ background: "#fff", borderTop: `1px solid ${SEV_BORDER[sev]}` }}>
                          {g.items.map((d, i) => {
                            const itemActive = d.face_idxs && d.face_idxs.length > 0 && JSON.stringify(d.face_idxs.slice().sort()) === JSON.stringify([...selectedFaceIdxs].sort());
                            const hasLink = HAS_GEO && d.face_idxs && d.face_idxs.length > 0;
                            return (
                              <div
                                key={i}
                                className={hasLink ? `clickable-row${itemActive ? " active" : ""}` : ""}
                                onClick={() => hasLink && selectFaces(d.face_idxs, d.message, sev)}
                                style={{
                                  display: "grid", gridTemplateColumns: "72px 1fr",
                                  gap: 10, alignItems: "start",
                                  padding: "8px 12px",
                                  borderBottom: i < g.items.length - 1 ? `1px solid ${SEV_BORDER[sev]}` : "none",
                                  background: itemActive ? (sev === "critical" ? "#fee2e2" : sev === "warning" ? "#fef3c7" : "#f3f4f6") : (i % 2 === 0 ? "#fff" : "#fafafa"),
                                }}
                              >
                                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#9ca3af", paddingTop: 1 }}>Fix. {d.fixturing}</div>
                                <div style={{ fontSize: 11, color: "#374151", lineHeight: 1.5 }}>{d.message}</div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                      {/* SINGLE ITEM message */}
                      {!multi && (
                        <div style={{ background: "#fff", borderTop: `1px solid ${SEV_BORDER[sev]}`, padding: "8px 12px" }}>
                          <div style={{ fontSize: 11, color: "#374151", lineHeight: 1.55 }}>{g.items[0].message}</div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {totalFlags === 0 && (
            <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 6, padding: "13px 16px", display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#16a34a", flexShrink: 0 }} />
              <div style={{ fontSize: 13, color: "#15803d", fontWeight: 500 }}>No manufacturing flags — part appears suitable for standard CNC machining.</div>
            </div>
          )}

          {/* DRAWING INFO — only shown when a drawing PDF was parsed */}
          {R.drawing && R.drawing.has_drawing && (
            <div style={{ marginTop: 24 }}>
              <SectionHead>Drawing Info <span style={{ fontWeight: 400, letterSpacing: 0, textTransform: "none", color: "#999999", fontSize: 10 }}>— extracted from PDF</span></SectionHead>
              <div style={{ background: "#fff", border: "1px solid #e4e4e4", borderRadius: 10, overflow: "hidden" }}>

                {/* Summary row */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 1, background: "#e4e4e4" }}>
                  {[
                    { label: "Material", value: R.drawing.material || "—" },
                    { label: "Tightest Tolerance", value: R.drawing.tightest_tolerance != null ? (["position","flatness","perpendicularity","parallelism","concentricity","cylindricity","straightness","runout","total runout","circular runout","profile","profile of surface","profile of line","angularity","symmetry"].includes(R.drawing.tightest_tolerance_type||"") ? `${R.drawing.tightest_tolerance}` : `±${R.drawing.tightest_tolerance}`) : "—", sub: R.drawing.tightest_tolerance_type || "" },
                    { label: "Surface Finish", value: (() => {
                      if (!R.drawing.has_surface_finish) return "—";
                      const parts = [];
                      if (R.drawing.surface_finish_general && R.drawing.surface_finish_general.length > 0)
                        parts.push(`Ra ${R.drawing.surface_finish_general.join(", ")} (general)`);
                      if (R.drawing.surface_finish_individual && R.drawing.surface_finish_individual.length > 0)
                        parts.push(`Ra ${R.drawing.surface_finish_individual.join(", ")} (individual)`);
                      return parts.length > 0 ? parts.join("; ") : "Specified";
                    })() },
                    { label: "Datums", value: R.drawing.datums && R.drawing.datums.length > 0 ? R.drawing.datums.join(", ") : "—" },
                  ].map(cell => (
                    <div key={cell.label} style={{ background: "#fff", padding: "10px 12px" }}>
                      <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", color: "#9ca3af", textTransform: "uppercase", marginBottom: 3 }}>{cell.label}</div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: "#111111", fontWeight: 500 }}>{cell.value}</div>
                      {cell.sub && <div style={{ fontSize: 9, color: "#6d28d9", marginTop: 2, textTransform: "capitalize" }}>{cell.sub}</div>}
                    </div>
                  ))}
                </div>

                {/* General tolerance block — the title block .XX = ±.01 table */}
                {R.drawing.general_tolerances && (
                  <div style={{ borderTop: "1px solid #e4e4e4", padding: "10px 12px" }}>
                    <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", color: "#9ca3af", textTransform: "uppercase", marginBottom: 6 }}>General Tolerances (Unless Otherwise Specified)</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                      {Object.entries(R.drawing.general_tolerances).filter(([k]) => !isNaN(k)).sort(([a],[b]) => a - b).map(([places, val]) => (
                        <div key={places} style={{ display: "flex", alignItems: "center", gap: 4, background: "#f9fafb", border: "1px solid #e5e7eb", borderRadius: 4, padding: "4px 8px" }}>
                          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#6b7280" }}>{"." + "X".repeat(Number(places))}</span>
                          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#111111", fontWeight: 500 }}>±{val}</span>
                        </div>
                      ))}
                      {R.drawing.general_tolerances.angular_deg != null && (
                        <div style={{ display: "flex", alignItems: "center", gap: 4, background: "#f9fafb", border: "1px solid #e5e7eb", borderRadius: 4, padding: "4px 8px" }}>
                          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#6b7280" }}>Angular</span>
                          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#111111", fontWeight: 500 }}>±{R.drawing.general_tolerances.angular_deg}°</span>
                        </div>
                      )}
                      {R.drawing.general_tolerances.fractional != null && (
                        <div style={{ display: "flex", alignItems: "center", gap: 4, background: "#f9fafb", border: "1px solid #e5e7eb", borderRadius: 4, padding: "4px 8px" }}>
                          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#6b7280" }}>Fractional</span>
                          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#111111", fontWeight: 500 }}>±{R.drawing.general_tolerances.fractional}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* GD&T frames */}
                {R.drawing.gdt && R.drawing.gdt.length > 0 && (
                  <div style={{ borderTop: "1px solid #e4e4e4", padding: "10px 12px" }}>
                    <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", color: "#9ca3af", textTransform: "uppercase", marginBottom: 6 }}>GD&T Callouts</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                      {R.drawing.gdt.map((g, i) => (
                        <div key={i} style={{ display: "flex", alignItems: "center", gap: 4, background: "#f5f3ff", border: "1px solid #ddd6fe", borderRadius: 4, padding: "4px 8px" }}>
                          <span style={{ fontSize: 10, fontWeight: 600, color: "#6d28d9", textTransform: "capitalize" }}>{g.type.replace(/_/g, " ")}</span>
                          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#374151" }}>{g.tolerance}</span>
                          {g.datums && g.datums.length > 0 && (
                            <span style={{ fontSize: 9, color: "#9ca3af" }}>| {g.datums.join(" ")}</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Inline tolerances */}
                {R.drawing.inline_tolerances && R.drawing.inline_tolerances.length > 0 && (
                  <div style={{ borderTop: "1px solid #e4e4e4", padding: "10px 12px" }}>
                    <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", color: "#9ca3af", textTransform: "uppercase", marginBottom: 6 }}>Specific Tolerances</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                      {R.drawing.inline_tolerances.map((t, i) => (
                        <div key={i} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#374151", background: "#fef3c7", border: "1px solid #fde68a", borderRadius: 4, padding: "3px 7px" }}>
                          {t.nominal} ±{t.plus}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Process notes */}
                {R.drawing.process_notes && R.drawing.process_notes.length > 0 && (
                  <div style={{ borderTop: "1px solid #e4e4e4", padding: "10px 12px" }}>
                    <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", color: "#9ca3af", textTransform: "uppercase", marginBottom: 6 }}>Process Notes</div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                      {R.drawing.process_notes.map((n, i) => (
                        <div key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <span style={{ fontSize: 8, fontWeight: 600, color: "#6b7280", background: "#f3f4f6", padding: "1px 5px", borderRadius: 3, textTransform: "uppercase", letterSpacing: "0.06em", whiteSpace: "nowrap" }}>{n.category.replace(/_/g, " ")}</span>
                          <span style={{ fontSize: 11, color: "#374151" }}>{n.text}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Confidence + flag */}
                {R.drawing.flag && (
                  <div style={{ borderTop: "1px solid #e4e4e4", padding: "8px 12px", background: "#fffbeb" }}>
                    <span style={{ fontSize: 10, color: "#92400e" }}>⚠ {R.drawing.flag}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* FOOTER */}
          <div style={{ marginTop: 36, paddingTop: 14, borderTop: "1px solid #e4e4e4", display: "flex", justifyContent: "flex-end" }}>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#c0c0c0" }}>{R.filename}</div>
          </div>

      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
"""


def generate_report_html(report_dict, output_path=None):
    """
    Write a self-contained single-page HTML report with 3D viewer.

    Parameters
    ----------
    report_dict : dict
        Output of to_report_dict() from sourcing.pipeline.
    output_path : str or None
        Path to write the HTML file. If None, writes next to the STEP file
        as <stem>_report.html. If a directory, writes inside it.

    Returns
    -------
    str — absolute path of the written HTML file.
    """
    stem = pathlib.Path(report_dict["filename"]).stem

    if output_path is None:
        out = pathlib.Path(report_dict["filename"]).with_name(f"{stem}_report.html")
    else:
        out = pathlib.Path(output_path)
        if out.is_dir():
            out = out / f"{stem}_report.html"

    report_json = json.dumps(report_dict, ensure_ascii=False)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{report_dict['filename']} — Facet Part Report</title>
  <script crossorigin src="https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js"></script>
  <script crossorigin src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdn.sheetjs.com/xlsx-0.20.1/package/dist/xlsx.full.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/7.23.2/babel.min.js"></script>
</head>
<body style="margin:0;background:#f8f8f8">
  <div id="root"></div>
  <script>window.__REPORT__ = {report_json};</script>
  <script type="text/babel">{_COMPONENT_JSX}</script>
</body>
</html>"""

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    return str(out.resolve())